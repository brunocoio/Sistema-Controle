(() => {
    'use strict';

    let toastTimer;
    let removeTimer;

    const showToast = (message, tone = 'success') => {
        let toast = document.querySelector('[data-app-toast]');
        if (!(toast instanceof HTMLElement)) {
            toast = document.createElement('div');
            toast.className = 'app-toast';
            toast.dataset.appToast = '';
            document.body.append(toast);
        }

        toast.classList.remove('is-success', 'is-warning', 'is-danger', 'is-error', 'is-closing');
        toast.classList.add(`is-${tone}`);
        toast.textContent = message;
        toast.setAttribute('role', tone === 'error' ? 'alert' : 'status');
        toast.setAttribute('aria-live', tone === 'error' ? 'assertive' : 'polite');
        toast.hidden = false;
        window.clearTimeout(toastTimer);
        window.clearTimeout(removeTimer);
        toastTimer = window.setTimeout(() => {
            toast.classList.add('is-closing');
            removeTimer = window.setTimeout(() => {
                toast.hidden = true;
                toast.classList.remove('is-closing');
            }, 220);
        }, 4500);
    };

    const readJsonResponse = async (response) => {
        const body = await response.text();
        try {
            return JSON.parse(body);
        } catch {
            throw new Error('O servidor não retornou uma resposta válida. Atualize a página e tente novamente.');
        }
    };

    window.AppUI = Object.freeze({ showToast, readJsonResponse });

    document.querySelectorAll('[data-app-toast]').forEach((toast) => {
        const message = toast.textContent.trim();
        const tone = [...toast.classList].find((name) => name.startsWith('is-'))?.slice(3) || 'success';
        if (message) showToast(message, tone);
    });

    const confirmDialog = document.querySelector('[data-app-confirm-dialog]');
    let pendingConfirmation = null;
    if (confirmDialog instanceof HTMLDialogElement) {
        document.addEventListener('submit', (event) => {
            const form = event.target;
            if (!(form instanceof HTMLFormElement) || !form.matches('[data-app-confirm]')) return;
            if (form.dataset.confirmed === '1') { delete form.dataset.confirmed; return; }
            event.preventDefault();
            pendingConfirmation = form;
            const message = confirmDialog.querySelector('[data-app-confirm-message]');
            if (message) message.textContent = form.dataset.confirmMessage || 'Confirma esta ação?';
            confirmDialog.showModal();
        });
        const closeConfirmation = () => { if (confirmDialog.open) confirmDialog.close(); pendingConfirmation = null; };
        confirmDialog.querySelector('[data-app-confirm-cancel]')?.addEventListener('click', closeConfirmation);
        confirmDialog.querySelector('[data-app-confirm-accept]')?.addEventListener('click', () => {
            const form = pendingConfirmation;
            closeConfirmation();
            if (!(form instanceof HTMLFormElement)) return;
            form.dataset.confirmed = '1';
            form.requestSubmit();
        });
        confirmDialog.addEventListener('click', (event) => { if (event.target === confirmDialog) closeConfirmation(); });
    }
})();
