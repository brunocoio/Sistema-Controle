(() => {
    'use strict';

    let toastTimer;
    let removeTimer;

    const showToast = (message, tone = 'success') => {
        let toast = document.querySelector('[data-app-toast]');
        if (!(toast instanceof HTMLElement)) {
            toast = document.createElement('div');
            toast.className = 'app-toast';
            toast.dataset.appToast = '';
            document.body.append(toast);
        }

        toast.classList.remove('is-success', 'is-warning', 'is-danger', 'is-error', 'is-closing');
        toast.classList.add(`is-${tone}`);
        toast.textContent = message;
        toast.setAttribute('role', tone === 'error' ? 'alert' : 'status');
        toast.setAttribute('aria-live', tone === 'error' ? 'assertive' : 'polite');
        toast.hidden = false;
        window.clearTimeout(toastTimer);
        window.clearTimeout(removeTimer);
        toastTimer = window.setTimeout(() => {
            toast.classList.add('is-closing');
            removeTimer = window.setTimeout(() => {
                toast.hidden = true;
                toast.classList.remove('is-closing');
            }, 220);
        }, 4500);
    };

    const readJsonResponse = async (response) => {
        const body = await response.text();
        try {
            return JSON.parse(body);
        } catch {
            console.log('[Sistema FLAG] Resposta inválida do servidor.', {
                status: response.status,
                path: new URL(response.url).pathname,
            });
            throw new Error('O servidor não retornou uma resposta válida. Atualize a página e tente novamente.');
        }
    };

    const logRequestError = (operation, error, status = null) => {
        console.log('[Sistema FLAG] Falha na solicitação.', {
            operation,
            status,
            message: error instanceof Error ? error.message : 'Falha inesperada',
        });
    };

    window.AppUI = Object.freeze({ showToast, readJsonResponse, logRequestError });

    const sidebar = document.querySelector('[data-admin-sidebar]');
    const sidebarToggles = [...document.querySelectorAll('[data-admin-sidebar-toggle]')];
    const sidebarBackdrop = document.querySelector('[data-admin-sidebar-backdrop]');
    if (sidebar instanceof HTMLElement && sidebarToggles.length > 0) {
        const mobileLayout = window.matchMedia('(max-width: 760px)');
        const collapsed = () => document.body.classList.contains('admin-sidebar-collapsed');
        const mobileOpen = () => document.body.classList.contains('admin-sidebar-mobile-open');
        const syncToggle = () => {
            sidebarToggles.forEach((toggle) => toggle.setAttribute('aria-expanded', String(mobileLayout.matches ? mobileOpen() : !collapsed())));
            sidebar.dataset.collapsed = String(collapsed());
            sidebar.toggleAttribute('inert', mobileLayout.matches && !mobileOpen());
        };
        const closeMobileSidebar = () => {
            document.body.classList.remove('admin-sidebar-mobile-open');
            syncToggle();
        };
        sidebarToggles.forEach((sidebarToggle) => sidebarToggle.addEventListener('click', async () => {
            if (mobileLayout.matches) {
                document.body.classList.toggle('admin-sidebar-mobile-open');
                syncToggle();
                return;
            }
            const previous = collapsed();
            const next = !previous;
            document.body.classList.toggle('admin-sidebar-collapsed', next);
            syncToggle();
            const body = new URLSearchParams({ _csrf: sidebarToggle.dataset.csrf || '', sidebar_collapsed: next ? '1' : '0' });
            let responseStatus = null;
            try {
                const response = await fetch('ui-preferences.php', { method: 'POST', body, credentials: 'same-origin', headers: { Accept: 'application/json' } });
                responseStatus = response.status;
                const result = await readJsonResponse(response);
                if (!response.ok || !result.ok) throw new Error(result.message || 'Não foi possível salvar a preferência.');
            } catch (error) {
                logRequestError('Salvar preferência do menu', error, responseStatus);
                document.body.classList.toggle('admin-sidebar-collapsed', previous);
                syncToggle();
                showToast(error instanceof Error ? error.message : 'Não foi possível salvar a preferência.', 'error');
            }
        }));
        sidebarBackdrop?.addEventListener('click', closeMobileSidebar);
        document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && mobileOpen()) closeMobileSidebar(); });
        mobileLayout.addEventListener('change', () => { document.body.classList.remove('admin-sidebar-mobile-open'); syncToggle(); });
        syncToggle();
    }

    document.querySelectorAll('[data-app-toast]').forEach((toast) => {
        const message = toast.textContent.trim();
        const tone = [...toast.classList].find((name) => name.startsWith('is-'))?.slice(3) || 'success';
        if (message) showToast(message, tone);
    });

    const confirmDialog = document.querySelector('[data-app-confirm-dialog]');
    let pendingConfirmation = null;
    if (confirmDialog instanceof HTMLDialogElement) {
        document.addEventListener('submit', (event) => {
            const form = event.target;
            if (!(form instanceof HTMLFormElement) || !form.matches('[data-app-confirm]')) return;
            if (form.dataset.confirmed === '1') { delete form.dataset.confirmed; return; }
            event.preventDefault();
            pendingConfirmation = form;
            const message = confirmDialog.querySelector('[data-app-confirm-message]');
            if (message) message.textContent = form.dataset.confirmMessage || 'Confirma esta ação?';
            confirmDialog.showModal();
        });
        const closeConfirmation = () => { if (confirmDialog.open) confirmDialog.close(); pendingConfirmation = null; };
        confirmDialog.querySelector('[data-app-confirm-cancel]')?.addEventListener('click', closeConfirmation);
        confirmDialog.querySelector('[data-app-confirm-accept]')?.addEventListener('click', () => {
            const form = pendingConfirmation;
            closeConfirmation();
            if (!(form instanceof HTMLFormElement)) return;
            form.dataset.confirmed = '1';
            form.requestSubmit();
        });
        confirmDialog.addEventListener('click', (event) => { if (event.target === confirmDialog) closeConfirmation(); });
    }
})();
