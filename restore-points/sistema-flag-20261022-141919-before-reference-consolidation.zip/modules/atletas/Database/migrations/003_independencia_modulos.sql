ALTER TABLE atletas DROP CONSTRAINT IF EXISTS atletas_criado_por_fkey;
ALTER TABLE atletas DROP CONSTRAINT IF EXISTS atletas_atualizado_por_fkey;
