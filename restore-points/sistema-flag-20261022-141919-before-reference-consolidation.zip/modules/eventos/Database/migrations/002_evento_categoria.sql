ALTER TABLE eventos
    ADD COLUMN IF NOT EXISTS categoria_id BIGINT;

CREATE INDEX IF NOT EXISTS eventos_categoria_inicio_idx ON eventos (categoria_id, inicio);
