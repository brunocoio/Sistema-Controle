ALTER TABLE eventos DROP CONSTRAINT IF EXISTS eventos_atleta_destaque_id_fkey;
ALTER TABLE eventos DROP CONSTRAINT IF EXISTS eventos_categoria_id_fkey;
ALTER TABLE eventos DROP CONSTRAINT IF EXISTS eventos_criado_por_fkey;
ALTER TABLE eventos DROP CONSTRAINT IF EXISTS eventos_atualizado_por_fkey;
ALTER TABLE evento_presencas DROP CONSTRAINT IF EXISTS evento_presencas_atleta_id_fkey;
